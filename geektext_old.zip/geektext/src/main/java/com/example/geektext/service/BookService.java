package com.example.geektext.service;

import com.example.geektext.database.BooksInterface;
import com.example.geektext.model.Books;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service
public class BookService {
    
    private final BooksInterface bookInterface;

    @Autowired
    public BookService(@Qualifier("Books")BooksInterface bookInterface) {
        this.bookInterface = bookInterface;
    }
    
    public int insertBook(Books source){
        return bookInterface.insertBook(source);
    }
}
