package com.example.geektext.database;

import com.example.geektext.model.Books;

public interface BooksInterface {
    int insertBook(Books source);
    
}
