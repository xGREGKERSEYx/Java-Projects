package com.example.geektext.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Books {
    private final String title;
    private final String author;
    private final String publisher;
    private final String genre;
    private final String isbn;

    public Books(@JsonProperty("title")String title, 
            @JsonProperty("author")String author, 
            @JsonProperty("publisher")String publisher, 
            @JsonProperty("genre")String genre, 
            @JsonProperty("isbn")String isbn) {
        this.title = title;
        this.author = author;
        this.publisher = publisher;
        this.genre = genre;
        this.isbn = isbn;
    }
    
    public Books(Books source) {
        this.title = source.title;
        this.author = source.author;
        this.publisher = source.publisher;
        this.genre = source.genre;
        this.isbn = source.isbn;
    }
    

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getPublisher() {
        return publisher;
    }

    public String getGenre() {
        return genre;
    }

    public String getIsbn() {
        return isbn;
    }
    
    
    
    
    
}
