
package com.example.geektext.database;

import com.example.geektext.model.Books;
import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Repository;

@Repository("Books")// This class serves as a Repo
public class BooksDatabase implements BooksInterface{

    private static List<Books> Group21 = new ArrayList<>();
        
    @Override
    public int insertBook(Books source) {
        Group21.add(new Books(source.getTitle(), source.getAuthor(), 
                source.getPublisher(), source.getGenre(), source.getIsbn()));
        return 1;
    }
    
}
